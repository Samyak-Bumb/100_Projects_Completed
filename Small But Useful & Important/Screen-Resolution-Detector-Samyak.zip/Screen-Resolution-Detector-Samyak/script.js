let reso = document.getElementById("reso");
reso.textContent = `${window.screen.width} X ${window.screen.height}`;