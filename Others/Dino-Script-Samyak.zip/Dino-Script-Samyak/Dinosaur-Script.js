
// *Now* Not Created By Samyak (Only Written by Samyak😂😂)

  var original=Runner.prototype.gameOver=function(){}

/* 
Steps to Run This Code :-
1. In Chrome Browser type --> chrome://dino
2. Press Ctrl+Shift+I (Inspect) or Right Click and Click on Inspect
3. Go in Console
4. Paste The Code & Hit Enter 
*/
