let logo = document.querySelector('logo');
logo.addEventListener('click', (logo)=>{
    window.history.back();
});
