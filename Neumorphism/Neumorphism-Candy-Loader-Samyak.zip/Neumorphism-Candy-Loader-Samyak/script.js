const root = document.documentElement;
const chooseTheme = (color) => {
  root.style.setProperty('--yellow', color);
};